# MiniC

A lexer/parser for a C minilanguage

## Run it on repl.it

[![Run on Repl.it](https://repl.it/badge/github/murraypatterson/minic)](https://repl.it/github/murraypatterson/minic)
